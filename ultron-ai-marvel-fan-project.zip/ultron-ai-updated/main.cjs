const { app, BrowserWindow, dialog, ipcMain, session, shell } = require('electron');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');

const appRoot = __dirname;
const htmlPath = path.join(appRoot, 'index.html');
const mediaApproval = new Set();
let server;
let mainWindow;
let appPort;
let speechChild;
let speechRequestId = 0;
const vpnTypes = /^(vpn|wireguard|tun|tap)$/i;

// Enable Chromium's Vulkan WebGPU path before Chromium starts. The Linux
// distribution uses its bundled Chromium and does not search for system Chrome.
app.commandLine.appendSwitch('enable-unsafe-webgpu');
app.commandLine.appendSwitch('enable-features', 'Vulkan,VulkanFromANGLE,DefaultANGLEVulkan');
app.commandLine.appendSwitch('use-angle', 'vulkan');
app.commandLine.appendSwitch('ozone-platform', 'x11');

app.setName('ULTRON AI Marvel');
app.setPath('userData', process.env.ULTRON_APP_DATA || path.join(app.getPath('home'), '.local', 'share', 'ultron-ai', 'electron-profile'));

function isAppOrigin(origin) {
  try {
    const url = new URL(origin);
    return url.protocol === 'http:' && url.hostname === '127.0.0.1' && url.port === String(appPort);
  } catch (_) {
    return false;
  }
}

function configureMediaPermissions() {
  const localMediaApproved = (origin, details) => {
    if (!isAppOrigin(origin)) return false;
    const type = details && details.mediaType;
    if (type === 'audio' || type === 'video') return mediaApproval.has(type);
    return mediaApproval.has('audio') && mediaApproval.has('video');
  };

  // A denied check makes Chromium invoke the request handler below. After the
  // user approves, checks succeed for the rest of this app session.
  session.defaultSession.setPermissionCheckHandler((webContents, permission, requestingOrigin, details) => {
    if (permission !== 'media') return false;
    const origin = requestingOrigin || (webContents && webContents.getURL());
    return localMediaApproved(origin, details);
  });

  session.defaultSession.setPermissionRequestHandler(async (webContents, permission, callback, details) => {
    if (permission !== 'media' || !webContents || webContents.isDestroyed() || !isAppOrigin(webContents.getURL())) {
      callback(false);
      return;
    }

    const mediaTypes = Array.isArray(details && details.mediaTypes) && details.mediaTypes.length
      ? details.mediaTypes.filter(type => type === 'audio' || type === 'video')
      : ['audio', 'video'];
    if (!mediaTypes.length) {
      callback(false);
      return;
    }
    if (mediaTypes.every(type => mediaApproval.has(type))) {
      callback(true);
      return;
    }

    const requested = [...new Set(mediaTypes)];
    const names = requested.map(type => type === 'video' ? 'Kamera' : 'Mikrofon').join(' und ');
    try {
      const result = await dialog.showMessageBox(BrowserWindow.fromWebContents(webContents), {
        type: 'question',
        title: 'ULTRON – Gerätefreigabe',
        message: 'ULTRON möchte auf ' + names + ' zugreifen.',
        detail: 'Der Zugriff wird nur während des Calls verwendet. Kamera und Handerkennung laufen lokal auf diesem Gerät.',
        buttons: ['Erlauben', 'Abbrechen'],
        defaultId: 0,
        cancelId: 1,
        noLink: true,
      });
      if (result.response === 0) requested.forEach(type => mediaApproval.add(type));
      callback(result.response === 0);
    } catch (_) {
      callback(false);
    }
  });
}

function serveFile(response, filePath, contentType, cacheControl) {
  response.writeHead(200, {
    'Content-Type': contentType,
    'Cache-Control': cacheControl,
    'X-Content-Type-Options': 'nosniff',
  });
  fs.createReadStream(filePath).pipe(response);
}

function serveApp() {
  return new Promise((resolve, reject) => {
    server = http.createServer((request, response) => {
      if (request.method !== 'GET') {
        response.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Method not allowed');
        return;
      }

      let requestPath;
      try {
        requestPath = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
      } catch (_) {
        response.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Bad request');
        return;
      }

      if (requestPath === '/') {
        serveFile(response, htmlPath, 'text/html; charset=utf-8', 'no-store');
        return;
      }
      if (requestPath === '/manifest.webmanifest') {
        response.writeHead(200, { 'Content-Type': 'application/manifest+json; charset=utf-8', 'Cache-Control': 'no-store' });
        response.end(JSON.stringify({ name: 'ULTRON AI', short_name: 'ULTRON', start_url: '/', display: 'standalone', background_color: '#080b10', theme_color: '#080b10' }));
        return;
      }

      const isCallScript = requestPath === '/call.js';
      const isWebLLMAsset = requestPath === '/vendor/webllm.bundle.js';
      const isHandModel = requestPath.startsWith('/models/');
      const isVisionAsset = requestPath.startsWith('/vendor/mediapipe/');
      const isVoskAsset = requestPath.startsWith('/vendor/vosk/');
      if (!isCallScript && !isWebLLMAsset && !isHandModel && !isVisionAsset && !isVoskAsset) {
        response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Not found');
        return;
      }

      const filePath = path.resolve(appRoot, '.' + requestPath);
      if (!filePath.startsWith(appRoot + path.sep)) {
        response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Not found');
        return;
      }
      let stat;
      try { stat = fs.statSync(filePath); } catch (_) { stat = null; }
      if (!stat || !stat.isFile()) {
        response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        response.end('Not found');
        return;
      }

      const extension = path.extname(filePath).toLowerCase();
      const contentTypes = {
        '.js': 'text/javascript; charset=utf-8',
        '.mjs': 'text/javascript; charset=utf-8',
        '.wasm': 'application/wasm',
        '.task': 'application/octet-stream',
        '.txt': 'text/plain; charset=utf-8',
      };
      // App code must not be cached for a year: that kept stale call.js alive
      // after the installed app was updated. Large, versioned media assets can
      // still use immutable caching.
      const cacheControl = (isCallScript || isWebLLMAsset) ? 'no-store' : 'public, max-age=31536000, immutable';
      serveFile(response, filePath, contentTypes[extension] || 'application/octet-stream', cacheControl);
    });
    // WebLLM stores model weights per origin. A changing ephemeral port creates a
    // new origin at every launch and makes the app download the model again.
    const portFile = path.join(app.getPath('userData'), 'server-port.txt');
    let savedPort = 0;
    try {
      const value = Number(fs.readFileSync(portFile, 'utf8').trim());
      if (Number.isInteger(value) && value >= 1024 && value <= 65535) savedPort = value;
    } catch (_) {}
    const candidates = [...new Set([savedPort, ...Array.from({ length: 20 }, (_, index) => 43821 + index)].filter(Boolean))];
    let portIndex = 0;
    const listenNext = () => {
      const port = candidates[portIndex++];
      const onError = error => {
        server.removeListener('listening', onListening);
        if (error.code === 'EADDRINUSE' && portIndex < candidates.length) return listenNext();
        reject(error);
      };
      const onListening = () => {
        server.removeListener('error', onError);
        appPort = server.address().port;
        fs.mkdirSync(path.dirname(portFile), { recursive: true });
        fs.writeFileSync(portFile, String(appPort), 'utf8');
        resolve(appPort);
      };
      server.once('error', onError);
      server.once('listening', onListening);
      server.listen(port, '127.0.0.1');
    };
    listenNext();
  });
}

function isPathInside(parent, candidate) {
  const relative = path.relative(parent, candidate);
  return relative === '' || (relative !== '..' && !relative.startsWith('..' + path.sep) && !path.isAbsolute(relative));
}

function runInstaller(scriptPath, sourceRoot) {
  return new Promise(resolve => {
    let stdout = '';
    let stderr = '';
    const child = spawn('sh', [scriptPath], { cwd: sourceRoot, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
    child.stdout.on('data', chunk => { stdout += chunk.toString(); });
    child.stderr.on('data', chunk => { stderr += chunk.toString(); });
    child.once('error', error => resolve({ ok: false, message: error.message }));
    child.once('close', code => {
      resolve(code === 0
        ? { ok: true, message: stdout.trim() || 'ULTRON wurde installiert.' }
        : { ok: false, message: (stderr || stdout || `Installationsskript beendet mit Code ${code}.`).trim() });
    });
  });
}

ipcMain.handle('ultron:install', async () => {
  const sourceRoot = path.resolve(appRoot, '..');
  const dataHome = process.env.XDG_DATA_HOME || path.join(app.getPath('home'), '.local', 'share');
  const installRoot = path.resolve(dataHome, 'ultron-ai');
  const scriptPath = path.join(sourceRoot, 'installieren.sh');

  if (!fs.existsSync(scriptPath) || !fs.existsSync(path.join(sourceRoot, 'electron', 'electron'))) {
    return { ok: false, message: 'Die Installationsdateien fehlen. Bitte ULTRON aus dem vollständigen Linux-ZIP starten.' };
  }

  if (isPathInside(installRoot, sourceRoot)) {
    return { ok: true, alreadyInstalled: true, message: 'ULTRON ist bereits installiert. Du findest es im Mint-Startmenü unter „ULTRON AI“.' };
  }

  return runInstaller(scriptPath, sourceRoot);
});

function trustedAppRequest(event) {
  return !!(event && event.senderFrame && isAppOrigin(event.senderFrame.url));
}

function speakWithPiper(text, rate) {
  const helperPath = path.join(appRoot, 'tts_speak.py');
  const voicePath = path.join(appRoot, 'models', 'de_DE-thorsten-medium.onnx');
  const pythonPath = path.join(appRoot, 'vendor', 'piper-python');
  if (!fs.existsSync(helperPath) || !fs.existsSync(voicePath) || !fs.existsSync(pythonPath)) return Promise.resolve(null);

  const outputPath = path.join(os.tmpdir(), `ultron-voice-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}.wav`);
  return new Promise(resolve => {
    let settled = false;
    const child = spawn('python3', [helperPath, voicePath, outputPath, String(rate)], {
      cwd: appRoot,
      env: { ...process.env, PYTHONPATH: pythonPath + (process.env.PYTHONPATH ? path.delimiter + process.env.PYTHONPATH : ''), PYTHONDONTWRITEBYTECODE: '1' },
      stdio: ['pipe', 'ignore', 'pipe'],
    });
    speechChild = child;
    let errorOutput = '';
    const timeout = setTimeout(() => {
      child.kill();
      finish(null);
    }, 90000);
    const finish = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (speechChild === child) speechChild = null;
      try { fs.rmSync(outputPath, { force: true }); } catch (_) {}
      resolve(result);
    };
    child.stderr.on('data', chunk => { if (errorOutput.length < 12000) errorOutput += chunk.toString(); });
    child.once('error', () => finish(null));
    child.once('close', code => {
      if (code !== 0) {
        if (errorOutput.trim()) console.warn('ULTRON Piper-Stimme:', errorOutput.trim());
        finish(null);
        return;
      }
      try {
        const audio = fs.readFileSync(outputPath);
        if (audio.length <= 44) return finish(null);
        finish({ ok: true, backend: 'piper-neural', audio: audio.toString('base64') });
      } catch (_) { finish(null); }
    });
    child.stdin.once('error', () => finish(null));
    child.stdin.end(text);
  });
}

ipcMain.handle('ultron:speak', async (event, request = {}) => {
  if (!trustedAppRequest(event)) return { ok: false, message: 'Sprachausgabe ist nur in der ULTRON-App verfügbar.' };
  const text = String(request.text || '').trim();
  if (!text) return { ok: false, message: 'Kein Text zum Vorlesen.' };

  const clamp = (value, minimum, maximum, fallback) => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(maximum, Math.max(minimum, number)) : fallback;
  };
  const rate = clamp(request.rate, 0.6, 1.5, 1);
  const requestId = ++speechRequestId;

  if (speechChild && !speechChild.killed) speechChild.kill();
  speechChild = null;
  if (request.style !== 'natural') return { ok: false, message: 'ULTRON verwendet nur die neue natürliche deutsche Stimme.' };
  const neuralSpeech = await speakWithPiper(text, rate);
  if (requestId !== speechRequestId) return { ok: false, message: 'Sprachausgabe wurde beendet.' };
  return neuralSpeech || { ok: false, message: 'Die neue natürliche Stimme konnte nicht gestartet werden. Prüfe das installierte ULTRON-Stimmenmodell.' };
});

ipcMain.handle('ultron:stop-speech', event => {
  if (!trustedAppRequest(event)) return { ok: false };
  speechRequestId++;
  if (speechChild && !speechChild.killed) speechChild.kill();
  speechChild = null;
  // Speech Dispatcher may keep speaking after its client process closes.
  // Cancel its queued output so ending a call also silences ULTRON.
  return new Promise(resolve => {
    const cancel = spawn('spd-say', ['--cancel'], { stdio: 'ignore' });
    cancel.once('error', () => resolve({ ok: false }));
    cancel.once('close', () => resolve({ ok: true }));
  });
});

function runNmcli(args) {
  return new Promise(resolve => {
    let stdout = '';
    let stderr = '';
    const child = spawn('nmcli', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const timer = setTimeout(() => {
      child.kill();
      resolve({ ok: false, message: 'NetworkManager hat nicht rechtzeitig geantwortet.' });
    }, 30000);
    const finish = result => { clearTimeout(timer); resolve(result); };
    child.stdout.on('data', chunk => { if (stdout.length < 100000) stdout += chunk.toString(); });
    child.stderr.on('data', chunk => { if (stderr.length < 100000) stderr += chunk.toString(); });
    child.once('error', error => finish({ ok: false, message: error.code === 'ENOENT' ? 'nmcli/NetworkManager ist auf diesem Linux-System nicht verfügbar.' : error.message }));
    child.once('close', code => finish(code === 0
      ? { ok: true, stdout: stdout.trim() }
      : { ok: false, message: stderr.trim() || `NetworkManager meldete Fehlercode ${code}.` }));
  });
}

function parseNmcliFields(line) {
  const fields = [];
  let value = '';
  let escaped = false;
  for (const character of line) {
    if (escaped) { value += character; escaped = false; }
    else if (character === '\\') escaped = true;
    else if (character === ':') { fields.push(value); value = ''; }
    else value += character;
  }
  if (escaped) value += '\\';
  fields.push(value);
  return fields;
}

async function listVpnProfiles() {
  const [saved, active] = await Promise.all([
    runNmcli(['--terse', '--escape', 'yes', '--fields', 'UUID,NAME,TYPE', 'connection', 'show']),
    runNmcli(['--terse', '--escape', 'yes', '--fields', 'UUID', 'connection', 'show', '--active']),
  ]);
  if (!saved.ok) return saved;
  if (!active.ok) return active;
  const activeIds = new Set(active.stdout.split(/\r?\n/).filter(Boolean).map(line => parseNmcliFields(line)[0]));
  const profiles = saved.stdout.split(/\r?\n/).filter(Boolean).flatMap(line => {
    const [uuid, name, type] = parseNmcliFields(line);
    if (!uuid || !vpnTypes.test(type || '')) return [];
    return [{ uuid, name, type, active: activeIds.has(uuid) }];
  });
  return { ok: true, profiles };
}

ipcMain.handle('ultron:vpn-list', async event => {
  if (!trustedAppRequest(event)) return { ok: false, message: 'VPN-Steuerung ist nur in der ULTRON-App verfügbar.' };
  const result = await listVpnProfiles();
  return result.ok ? { ok: true, profiles: result.profiles } : result;
});

ipcMain.handle('ultron:vpn-connect', async (event, request = {}) => {
  if (!trustedAppRequest(event)) return { ok: false, message: 'VPN-Steuerung ist nur in der ULTRON-App verfügbar.' };
  const uuid = String(request.uuid || '');
  if (!/^[a-f0-9-]{16,64}$/i.test(uuid)) return { ok: false, message: 'Wähle zuerst ein vorhandenes VPN-Profil aus.' };
  const listed = await listVpnProfiles();
  if (!listed.ok) return listed;
  if (!listed.profiles.some(profile => profile.uuid === uuid)) return { ok: false, message: 'Das ausgewählte VPN-Profil wurde nicht gefunden.' };
  const result = await runNmcli(['--wait', '20', 'connection', 'up', 'uuid', uuid]);
  return result.ok ? { ok: true, message: 'VPN verbunden.' } : result;
});

ipcMain.handle('ultron:vpn-disconnect', async (event, request = {}) => {
  if (!trustedAppRequest(event)) return { ok: false, message: 'VPN-Steuerung ist nur in der ULTRON-App verfügbar.' };
  const uuid = String(request.uuid || '');
  if (!/^[a-f0-9-]{16,64}$/i.test(uuid)) return { ok: false, message: 'Wähle zuerst ein vorhandenes VPN-Profil aus.' };
  const listed = await listVpnProfiles();
  if (!listed.ok) return listed;
  const profile = listed.profiles.find(item => item.uuid === uuid);
  if (!profile) return { ok: false, message: 'Das ausgewählte VPN-Profil wurde nicht gefunden.' };
  if (!profile.active) return { ok: false, message: 'Dieses VPN-Profil ist gerade nicht verbunden.' };
  const result = await runNmcli(['--wait', '20', 'connection', 'down', 'uuid', uuid]);
  return result.ok ? { ok: true, message: 'VPN getrennt.' } : result;
});

async function createWindow() {
  const port = await serveApp();
  configureMediaPermissions();
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 850,
    minWidth: 800,
    minHeight: 600,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#080b10',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(appRoot, 'preload.cjs'),
    },
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith(`http://127.0.0.1:${port}/`)) {
      event.preventDefault();
      if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    }
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => { mainWindow = null; app.quit(); });
  await mainWindow.loadURL(`http://127.0.0.1:${port}/`);
}

app.whenReady().then(createWindow).catch(error => {
  console.error('ULTRON konnte nicht gestartet werden:', error);
  app.quit();
});

app.on('before-quit', () => {
  if (server) server.close();
  if (speechChild && !speechChild.killed) speechChild.kill();
});

app.on('window-all-closed', () => app.quit());
