# ULTRON AI Marvel — independent fan project

An independent desktop experiment inspired by fictional AI interfaces. This project is **not affiliated with, sponsored by, or endorsed by Marvel or Disney**. Marvel and related character names/logos are owned by their respective rights holders. Before public distribution, replace any copyrighted images, marks, or character-specific assets with original or properly licensed material.

## Features
- Electron desktop UI for Linux
- First-run language chooser: English, German, Spanish, French, Italian, Portuguese, Turkish, Polish, Russian, Ukrainian, Hindi, Japanese, Korean, and Chinese
- Language selector remains available in the header
- Existing local model / web research / voice and hand interaction features are retained in the source

## Privacy checklist before publishing
- Do not commit tokens, API keys, passwords, browser profiles, local model caches, or personal data.
- Do not include local absolute paths, local diagnostic logs, or the user's home directory.
- API keys should be entered by the user at runtime and must not be hardcoded.
- Review all images/assets for ownership and personal metadata.
- The desktop source can request camera/microphone permissions; users should approve only when they start the relevant call feature.
- The language choice is stored locally in the app's localStorage.

## Build notes
The project depends on local runtime assets in `vendor/`, `models/`, and `preload.cjs`. Those assets must be audited and included appropriately for a complete build. This source bundle alone is not a standalone complete release.

## License
The source metadata declares MIT for original code only. Third-party dependencies, models, images, logos, and character artwork remain under their own licenses and are not relicensed by this file.
