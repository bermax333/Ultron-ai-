let ultronCallStarting = false;
let ultronCallStream = null;
let ultronCallRequest = 0;
let ultronCallCameraReady = false;
let ultronCallMicReady = false;
let ultronHandLandmarker = null;
let ultronHandRaf = 0;
let ultronOrbitRaf = 0;
let ultronLastVideoTime = -1;
let ultronLastDetectionAt = 0;
let ultronHandPoint = null;
let ultronHandTarget = null;
let ultronHandCursor = null;
let ultronHandRaw = null;
let ultronHandFiltered = null;
let ultronHandAnchor = null;
let ultronHandPinching = false;
let ultronLastHandSeenAt = 0;
let ultronPointer = { x: 0.5, y: 0.5 };
let ultronOrbitAngle = 0;
let ultronOrbitTilt = 0;
let ultronOrbitLastFrame = 0;
let ultronMicVisualLevel = 0;
let ultronCallSpeaking = false;
let ultronRecognitionTimer = 0;
let ultronRecognitionBlocked = false;
let ultronRecognitionRetryDelay = 700;
let ultronRecognitionMode = 'idle';
let ultronVoskClient = null;
let ultronVoskRecognizer = null;
let ultronLocalAudioContext = null;
let ultronLocalAudioSource = null;
let ultronLocalAudioHighpass = null;
let ultronLocalAudioGain = null;
let ultronLocalAudioCompressor = null;
let ultronLocalAudioProcessor = null;
let ultronLocalAudioMute = null;
let ultronAudioContext = null;
let ultronAudioAnalyser = null;
let ultronAudioSource = null;
let ultronAudioSilentGain = null;
let ultronAudioMeterTimer = 0;
let ultronMicContext = null;
let ultronMicAnalyser = null;
let ultronMicSource = null;
let ultronMicSilentGain = null;
let ultronMicMeterTimer = 0;
let ultronMicStartedAt = 0;
let ultronMicHeardVoice = false;
let ultronMicNoToneReported = false;
let ultronMicLastVoiceAt = 0;
let ultronSpeechRecorder = null;
let ultronSpeechRecorderParts = [];
let ultronSpeechStartedAt = 0;
let ultronSpeechLastVoiceAt = 0;
let ultronDiscardSpeechSegment = false;
let ultronSpeechRequestActive = false;
let ultronSpeechRequestQueue = [];
let ultronOnlineSpeechFailed = false;
let ultronSpeechController = null;
let ultronSpeechNoiseFloor = 0.0025;
let ultronSpeechCandidateAt = 0;
let ultronSpeechSetupTimer = 0;
let ultronCallLastUtterance = '';
let ultronCallTopicText = '';
let ultronCallPartialText = '';
let ultronCallPartialTimer = 0;
let ultronCallTranscriptBuffer = '';
let ultronCallTranscriptTimer = 0;
let ultronCallLastCommittedTranscript = '';
let ultronCallLastCommittedAt = 0;
let ultronCallOrbitImageItems = [];

function ultronCallSignal(id, message, state = 'neutral', detail = '') {
  const signal = document.getElementById(id);
  if (!signal) return;
  signal.textContent = message;
  signal.dataset.state = state;
  signal.title = detail;
}

function ultronCameraProblem(error) {
  const message = String(error?.message || '');
  const name = String(error?.name || '');
  if (name === 'NotAllowedError' || name === 'PermissionDeniedError') return 'Freigabe fehlt';
  if (name === 'NotFoundError' || /Kamera: NotFoundError/i.test(message)) return 'kein Gerät gefunden';
  if (name === 'NotReadableError' || /Kamera: NotReadableError/i.test(message)) return 'belegt oder gesperrt';
  if (name === 'OverconstrainedError') return 'Einstellung nicht unterstützt';
  if (/kein Kamerabild|liefert kein Bild/i.test(message)) return 'liefert kein Bild';
  return 'Start fehlgeschlagen';
}

function ultronSetSpeechSetupVisible(visible) {
  const button = document.getElementById('callSpeechSetup');
  if (button) button.hidden = !visible;
}

function ultronCallStatus(message) {
  const callStatus = document.getElementById('callStatus');
  const oldStatus = document.getElementById('voiceStatus');
  if (callStatus) callStatus.textContent = message;
  if (oldStatus) oldStatus.textContent = message;
}

function ultronTrimCallText(text, limit = 150) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (clean.length <= limit) return clean;
  const cut = clean.slice(0, limit - 1);
  const lastSpace = cut.lastIndexOf(' ');
  return (lastSpace > limit * 0.65 ? cut.slice(0, lastSpace) : cut) + '…';
}

function ultronUpdateCallTopic(utterance, answer = '', partial = false) {
  const raw = String(utterance || '').replace(/^\s*ultron[,:\s-]*/i, '').trim();
  const topic = ultronTrimCallText(raw || 'Sprich mit ULTRON, um ein Thema zu sehen.', 74);
  const title = document.getElementById('callTopicTitle');
  const summary = document.getElementById('callTopicSummary');
  const card = document.getElementById('callTopicCard');
  if (title) title.textContent = partial ? 'Ich höre: ' + topic : topic;
  if (summary) summary.textContent = partial
    ? 'Live-Transkript · sprich weiter …'
    : ultronTrimCallText(answer || 'ULTRON verarbeitet das Gesprächsthema …', 150);
  if (card) card.classList.toggle('is-updating', partial);
  ultronCallTopicText = topic;
  if (!partial) ultronCallLastUtterance = raw;
}

window.ultronSetCallOrbitImages = items => {
  const container = document.getElementById('callOrbitImages');
  if (!container) return;
  const safeItems = (Array.isArray(items) ? items : []).filter(item => {
    const image = String(item?.image || '');
    const articleUrl = String(item?.url || '');
    let safeArticle = false;
    try { const parsedArticle = new URL(articleUrl); safeArticle = parsedArticle.protocol === 'https:'; } catch (_) {}
    const safeGenerated = item?.generated === true && /^data:image\/(?:png|jpe?g|webp|gif);base64,/i.test(image);
    if (!image) return safeArticle && String(item?.summary || item?.text || '').trim().length > 0;
    if (safeGenerated) return true;
    try {
      const url = new URL(image);
      return url.protocol === 'https:' && (url.hostname.toLowerCase().endsWith('.wikimedia.org') || item?.generated === true);
    } catch (_) { return false; }
  }).slice(0, 3);
  ultronCallOrbitImageItems = safeItems;
  container.replaceChildren();
  safeItems.forEach(item => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'call-orbit-image';
    const title = String(item.title || 'Bild zum Gesprächsthema');
    card.title = title + ' · anklicken zum Vergrößern';
    card.setAttribute('aria-label', 'Bild vergrößern: ' + title);
    const imageUrl = String(item.image || '');
    if (imageUrl) {
      const image = document.createElement('img');
      image.src = imageUrl;
      image.alt = title;
      image.loading = 'lazy';
      image.referrerPolicy = 'no-referrer';
      image.onerror = () => { image.remove(); card.classList.add('call-orbit-text-only'); };
      card.append(image);
    } else {
      card.classList.add('call-orbit-text-only');
    }
    const caption = document.createElement('span');
    caption.textContent = ultronTrimCallText(title, 38);
    const summary = document.createElement('small');
    summary.textContent = ultronTrimCallText(item.summary || item.text || 'Quelle öffnen', 105);
    summary.className = 'call-orbit-summary';
    card.setAttribute('data-orbit-url', /^https:\/\//i.test(String(item.url || '')) ? String(item.url) : '');
    card.addEventListener('click', () => {
      if (imageUrl) ultronOpenCallImage(item);
      else if (/^https:\/\//i.test(String(item.url || ''))) window.open(item.url, '_blank', 'noopener,noreferrer');
    });
    card.append(caption, summary);
    container.append(card);
  });
};

function ultronOpenCallImage(item) {
  const dialog = document.getElementById('callImageViewer');
  const image = document.getElementById('callImageViewerImg');
  const title = document.getElementById('callImageViewerTitle');
  const source = document.getElementById('callImageViewerSource');
  if (!dialog || !image || !title) return;
  const imageUrl = String(item?.image || '');
  if (!/^https:\/\//i.test(imageUrl) && !/^data:image\//i.test(imageUrl)) return;
  title.textContent = String(item?.title || 'Bild zum Gesprächsthema');
  image.src = imageUrl;
  image.alt = title.textContent;
  if (source) {
    const sourceUrl = /^https:\/\//i.test(String(item?.url || '')) ? String(item.url) : imageUrl;
    source.href = sourceUrl;
    source.hidden = !/^https:\/\//i.test(sourceUrl);
  }
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.setAttribute('open', '');
}

document.getElementById('callImageViewerClose')?.addEventListener('click', () => {
  const dialog = document.getElementById('callImageViewer');
  if (dialog?.open) dialog.close();
  else dialog?.removeAttribute('open');
});
document.getElementById('callImageViewer')?.addEventListener('click', event => {
  if (event.target !== event.currentTarget) return;
  const dialog = event.currentTarget;
  if (dialog.open) dialog.close();
  else dialog.removeAttribute('open');
});

window.ultronUpdateCallAnswer = answer => {
  if (!calling || !ultronCallLastUtterance) return;
  const clean = typeof cleanAssistantSpeech === 'function' ? cleanAssistantSpeech(answer) : String(answer || '');
  const firstSentence = clean.split(/(?<=[.!?])\s+/)[0] || clean;
  ultronUpdateCallTopic(ultronCallLastUtterance, firstSentence, false);
};

function ultronSetMicMeter(level, label) {
  const meter = document.getElementById('callMicMeter');
  const fill = document.getElementById('callMicMeterFill');
  const value = document.getElementById('callMicMeterValue');
  const text = document.getElementById('callMicMeterText');
  const percent = Math.max(0, Math.min(100, Math.round(level * 100)));
  if (fill) fill.style.width = percent + '%';
  if (meter) meter.setAttribute('aria-valuenow', String(percent));
  if (value) value.textContent = percent + '%';
  if (label && text) text.textContent = label;
}

function ultronStopMicMonitor() {
  clearTimeout(ultronMicMeterTimer);
  ultronMicMeterTimer = 0;
  if (ultronMicSource) {
    try { ultronMicSource.disconnect(); } catch (_) {}
    ultronMicSource = null;
  }
  if (ultronMicSilentGain) {
    try { ultronMicSilentGain.disconnect(); } catch (_) {}
    ultronMicSilentGain = null;
  }
  ultronMicAnalyser = null;
  if (ultronMicContext) {
    const context = ultronMicContext;
    ultronMicContext = null;
    context.close().catch(() => {});
  }
  ultronMicVisualLevel = 0;
  ultronSetMicMeter(0, 'Mikrofonpegel – lokal auf diesem Gerät');
}

async function ultronStartMicMonitor(stream) {
  ultronStopMicMonitor();
  const track = stream.getAudioTracks().find(item => item.readyState === 'live');
  if (!track) {
    ultronCallSignal('callMicSignal', 'Mikrofon: keine Audiospur', 'bad');
    ultronSetMicMeter(0, 'Keine Mikrofonspur erhalten');
    return false;
  }
  ultronMicStartedAt = performance.now();
  ultronMicHeardVoice = false;
  ultronMicNoToneReported = false;
  ultronMicLastVoiceAt = 0;
  ultronCallSignal('callMicSignal', 'Mikrofon: verbunden, sprich jetzt', 'busy');
  ultronSetMicMeter(0, (track.label || 'Mikrofon') + ' · sprich kurz');
  track.addEventListener('mute', () => {
    if (calling) ultronCallSignal('callMicSignal', 'Mikrofon: Eingang stumm', 'bad');
  });
  track.addEventListener('unmute', () => {
    if (calling) ultronCallSignal('callMicSignal', ultronMicHeardVoice ? 'Mikrofon: Ton erkannt' : 'Mikrofon: verbunden, sprich jetzt', ultronMicHeardVoice ? 'good' : 'busy');
  });
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) throw new Error('Web Audio wird nicht unterstützt');
    ultronMicContext = new AudioContextClass();
    ultronMicAnalyser = ultronMicContext.createAnalyser();
    ultronMicAnalyser.fftSize = 1024;
    ultronMicSource = ultronMicContext.createMediaStreamSource(new MediaStream([track]));
    ultronMicSource.connect(ultronMicAnalyser);
    // Keep the analyser graph rendering while silencing its output to avoid mic feedback.
    ultronMicSilentGain = ultronMicContext.createGain();
    ultronMicSilentGain.gain.value = 0;
    ultronMicAnalyser.connect(ultronMicSilentGain);
    ultronMicSilentGain.connect(ultronMicContext.destination);
    await ultronMicContext.resume();
    if (!calling || ultronCallStream !== stream) {
      ultronStopMicMonitor();
      return false;
    }
    const meter = () => {
      if (!calling || !ultronMicAnalyser) return;
      const samples = new Float32Array(ultronMicAnalyser.fftSize);
      ultronMicAnalyser.getFloatTimeDomainData(samples);
      let energy = 0;
      for (let i = 0; i < samples.length; i++) energy += samples[i] * samples[i];
      const rms = Math.sqrt(energy / samples.length);
      const now = performance.now();
      ultronMicVisualLevel = Math.min(1, rms * 20);
      if (rms > 0.006) {
        ultronMicHeardVoice = true;
        ultronMicNoToneReported = false;
        ultronMicLastVoiceAt = now;
        ultronSetMicMeter(Math.min(1, rms * 16), 'Ton erkannt · Messung bleibt lokal');
        ultronCallSignal('callMicSignal', 'Mikrofon: Ton erkannt', 'good');
      } else if (ultronMicHeardVoice) {
        ultronSetMicMeter(Math.min(1, rms * 16), 'Ton zuletzt erkannt · Pegel aktuell leise');
        if (now - ultronMicLastVoiceAt > 500) ultronCallSignal('callMicSignal', 'Mikrofon: verbunden', 'good');
      } else if (!ultronMicHeardVoice && !ultronMicNoToneReported && performance.now() - ultronMicStartedAt > 6000) {
        ultronMicNoToneReported = true;
        ultronCallSignal('callMicSignal', 'Mikrofon: kein Ton erkannt', 'bad');
        ultronSetMicMeter(0, 'Kein Ton von ' + (track.label || 'Mikrofon') + ' · Stummschaltung prüfen');
      } else {
        ultronSetMicMeter(Math.min(1, rms * 16), (track.label || 'Mikrofon') + ' · sprich kurz');
      }
      ultronMicMeterTimer = setTimeout(meter, 100);
    };
    meter();
    return true;
  } catch (error) {
    console.warn('ULTRON lokaler Mikrofontest:', error);
    ultronStopMicMonitor();
    ultronCallSignal('callMicSignal', 'Mikrofon: Pegeltest nicht verfügbar', 'bad');
    ultronSetMicMeter(0, 'Mikrofonspur vorhanden, Pegeltest fehlgeschlagen');
    return false;
  }
}

function ultronRestartRecognition(delay = 700) {
  clearTimeout(ultronRecognitionTimer);
  ultronRecognitionTimer = setTimeout(() => {
    if (!calling || ultronCallSpeaking || !recognition || ultronRecognitionMode !== 'native') return;
    try { recognition.start(); }
    catch (_) { ultronCallStatus('Mikrofon aktiv; Spracherkennung startet erneut …'); }
  }, delay);
}

function ultronPollinationsKey() {
  return (document.getElementById('ultronOnlineApiKey')?.value || '').trim().replace(/^Bearer\s+/i, '');
}

function ultronHasLocalModel() {
  try { return typeof localEngine !== 'undefined' && !!localEngine; }
  catch (_) { return false; }
}

async function ultronCheckCallInternet() {
  if (!navigator.onLine) {
    ultronCallSignal('callInternetSignal', 'Internet: offline', 'bad');
    return false;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch('https://gen.pollinations.ai/v1/models', {
      method: 'GET', cache: 'no-store', signal: controller.signal
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    ultronCallSignal('callInternetSignal', 'Internet: verbunden', 'good');
    return true;
  } catch (error) {
    const reason = error.name === 'AbortError' ? 'Zeitüberschreitung' : 'Dienst nicht erreichbar';
    ultronCallSignal('callInternetSignal', 'Internet: ' + reason, 'bad');
    return false;
  } finally {
    clearTimeout(timer);
  }
}

function ultronQueueCallTranscript(heard) {
  const text = String(heard || '').replace(/\s+/g, ' ').trim().replace(/^(?:(?:ähm?|hm)[,.:;!?-]?\s*)+/i, '');
  if (!text || !calling || ultronCallSpeaking) return;
  const normalized = text.toLocaleLowerCase('de-DE').replace(/[\s.,!?;:]+$/g, '');
  const buffered = ultronCallTranscriptBuffer.toLocaleLowerCase('de-DE').replace(/[\s.,!?;:]+$/g, '');
  const now = Date.now();
  if (normalized === buffered || (normalized === ultronCallLastCommittedTranscript && now - ultronCallLastCommittedAt < 2500)) return;
  if (ultronCallTranscriptBuffer && normalized.startsWith(buffered + ' ')) {
    ultronCallTranscriptBuffer = text;
  } else if (ultronCallTranscriptBuffer && buffered.startsWith(normalized + ' ')) {
    // Keep the longer overlapping final transcript instead of repeating words.
  } else {
    ultronCallTranscriptBuffer = [ultronCallTranscriptBuffer, text].filter(Boolean).join(' ');
  }
  clearTimeout(ultronCallTranscriptTimer);
  // Native and offline recognizers often split one spoken thought at a short pause.
  // Wait briefly so ULTRON receives the complete sentence in a single request.
  ultronCallTranscriptTimer = setTimeout(() => {
    const complete = ultronCallTranscriptBuffer.trim();
    ultronCallTranscriptBuffer = '';
    ultronCallTranscriptTimer = 0;
    if (!complete || !calling || ultronCallSpeaking) return;
    ultronCallLastCommittedTranscript = complete.toLocaleLowerCase('de-DE').replace(/[\s.,!?;:]+$/g, '');
    ultronCallLastCommittedAt = Date.now();
    ultronHandleCallTranscript(complete);
  }, 850);
}

function ultronHandleCallTranscript(heard) {
  const text = String(heard || '').trim();
  if (!text || !calling || ultronCallSpeaking) return;
  clearTimeout(ultronCallPartialTimer);
  ultronCallPartialText = '';
  window.ultronSetCallOrbitImages([]);
  ultronUpdateCallTopic(text, 'ULTRON verarbeitet das Gesprächsthema …');
  ultronCallSignal('callSpeechSignal', 'Stimme: verstanden', 'good');
  ultronCallSignal('callAISignal', 'ULTRON: Anfrage wird verarbeitet', 'busy');
  addMsg(text, 'user');
  try {
    Promise.resolve(respond(text, { voiceCall: true })).catch(error => {
      console.error('ULTRON Call-Antwort:', error);
      ultronCallSignal('callAISignal', 'ULTRON: Antwort fehlgeschlagen', 'bad');
      ultronCallStatus('Ich habe dich verstanden, aber ULTRON konnte die Antwort nicht starten. Prüfe Modell und Online-Schlüssel.');
    });
  } catch (error) {
    console.error('ULTRON Call-Antwort:', error);
    ultronCallSignal('callAISignal', 'ULTRON: Antwort fehlgeschlagen', 'bad');
    ultronCallStatus('Ich habe dich verstanden, aber ULTRON konnte die Antwort nicht starten. Prüfe Modell und Online-Schlüssel.');
  }
}

function ultronStopSpeechSegment(discard = true) {
  const recorder = ultronSpeechRecorder;
  if (!recorder || recorder.state === 'inactive') return;
  ultronDiscardSpeechSegment = discard;
  try { recorder.stop(); } catch (_) {}
}

function ultronStopOnlineRecognition(discard = true) {
  clearTimeout(ultronAudioMeterTimer);
  ultronAudioMeterTimer = 0;
  ultronSpeechCandidateAt = 0;
  ultronStopSpeechSegment(discard);
  if (ultronSpeechController) {
    ultronSpeechController.abort();
    ultronSpeechController = null;
  }
  if (ultronAudioSource) {
    try { ultronAudioSource.disconnect(); } catch (_) {}
    ultronAudioSource = null;
  }
  if (ultronAudioSilentGain) {
    try { ultronAudioSilentGain.disconnect(); } catch (_) {}
    ultronAudioSilentGain = null;
  }
  ultronAudioAnalyser = null;
  if (ultronAudioContext) {
    const context = ultronAudioContext;
    ultronAudioContext = null;
    context.close().catch(() => {});
  }
  ultronSpeechRequestQueue = [];
}

function ultronStopLocalRecognition() {
  if (ultronLocalAudioProcessor) {
    ultronLocalAudioProcessor.onaudioprocess = null;
    try { ultronLocalAudioProcessor.disconnect(); } catch (_) {}
    ultronLocalAudioProcessor = null;
  }
  if (ultronLocalAudioSource) {
    try { ultronLocalAudioSource.disconnect(); } catch (_) {}
    ultronLocalAudioSource = null;
  }
  [ultronLocalAudioHighpass, ultronLocalAudioGain, ultronLocalAudioCompressor].forEach(node => {
    if (node) { try { node.disconnect(); } catch (_) {} }
  });
  ultronLocalAudioHighpass = null;
  ultronLocalAudioGain = null;
  ultronLocalAudioCompressor = null;
  if (ultronLocalAudioMute) {
    try { ultronLocalAudioMute.disconnect(); } catch (_) {}
    ultronLocalAudioMute = null;
  }
  if (ultronVoskRecognizer) {
    try { ultronVoskRecognizer.remove(); } catch (_) {}
    ultronVoskRecognizer = null;
  }
  if (ultronLocalAudioContext) {
    const context = ultronLocalAudioContext;
    ultronLocalAudioContext = null;
    context.close().catch(() => {});
  }
}

function ultronSpeechErrorMessage(response, detail) {
  if (response.status === 401) return 'API-Schlüssel ungültig oder abgelaufen';
  if (response.status === 402) return 'Pollinations-Guthaben oder Budget aufgebraucht';
  if (response.status === 429) return 'zu viele Anfragen; bitte kurz warten';
  if (response.status >= 500) return 'Pollinations-Sprachdienst meldet HTTP ' + response.status;
  return detail || 'HTTP ' + response.status;
}

async function ultronTranscribeSpeechBlob(blob) {
  if (!calling || ultronCallSpeaking || !blob || blob.size < 1200) return;
  const key = ultronPollinationsKey();
  if (!key) {
    ultronOnlineSpeechFailed = true;
    ultronStopOnlineRecognition(true);
    ultronRecognitionMode = 'blocked';
    ultronCallSignal('callSpeechSignal', 'Stimme: Online-Schlüssel fehlt', 'bad');
    ultronCallStatus('Chromium-Spracherkennung ist nicht erreichbar. Prüfe den lokalen Mikrofonpegel oben. Für Sprache-zu-Text brauchst du zusätzlich einen Pollinations-Schlüssel; das lokale Qwen-Modell versteht keinen Ton.');
    return;
  }
  const extension = blob.type.includes('ogg') ? 'ogg' : blob.type.includes('mp4') ? 'm4a' : 'webm';
  const form = new FormData();
  form.append('file', blob, 'ultron-call.' + extension);
  form.append('model', 'whisper-large-v3');
  form.append('language', 'de');
  form.append('response_format', 'text');
  const controller = new AbortController();
  ultronSpeechController = controller;
  const timer = setTimeout(() => controller.abort(), 30000);
  ultronCallSignal('callSpeechSignal', 'Stimme: wird online erkannt …', 'busy');
  try {
    const response = await fetch('https://gen.pollinations.ai/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + key },
      body: form,
      signal: controller.signal
    });
    const raw = await response.text();
    if (!response.ok) {
      let data = {};
      try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}
      throw Object.assign(new Error(ultronSpeechErrorMessage(response, data?.error?.message || data?.message || raw.slice(0, 180))), { status: response.status });
    }
    const transcript = raw.trim().replace(/^"([\s\S]*)"$/, '$1').trim();
    if (transcript && calling && !ultronCallSpeaking) ultronQueueCallTranscript(transcript);
    else if (calling) ultronCallSignal('callSpeechSignal', 'Stimme: bereit', 'good');
  } catch (error) {
    const reason = error.name === 'AbortError' ? 'Zeitüberschreitung bei der Spracherkennung' : error.message;
    ultronOnlineSpeechFailed = true;
    ultronRecognitionMode = 'blocked';
    ultronStopOnlineRecognition(true);
    if (window.ultronDesktop && calling && ultronCallStream) {
      ultronCallSignal('callSpeechSignal', 'Whisper nicht erreichbar · wechsle zu Vosk offline', 'busy');
      ultronCallStatus('Online-Erkennung fehlgeschlagen (' + reason + '). ULTRON wechselt zur deutschen Offline-Erkennung; das Mikrofon bleibt dann lokal.');
      void ultronStartLocalRecognition(ultronCallStream);
      return;
    }
    ultronCallSignal('callSpeechSignal', 'Stimme: ' + reason, 'bad');
    ultronCallStatus('Online-Spracherkennung fehlgeschlagen: ' + reason + '. Prüfe Internet, API-Schlüssel und Guthaben.');
  } finally {
    clearTimeout(timer);
    if (ultronSpeechController === controller) ultronSpeechController = null;
  }
}

function ultronStartSpeechSegment() {
  if (!calling || ultronCallSpeaking || ultronOnlineSpeechFailed || ultronSpeechRecorder || !ultronCallStream) return;
  const audioTracks = ultronCallStream.getAudioTracks().filter(track => track.readyState === 'live');
  if (!audioTracks.length) return;
  const audioStream = new MediaStream(audioTracks);
  const preferred = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
  const mimeType = preferred.find(type => typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported(type)) || '';
  try {
    const recorder = new MediaRecorder(audioStream, mimeType ? { mimeType } : undefined);
    ultronSpeechRecorder = recorder;
    ultronSpeechRecorderParts = [];
    ultronDiscardSpeechSegment = false;
    recorder.ondataavailable = event => {
      if (event.data && event.data.size) ultronSpeechRecorderParts.push(event.data);
    };
    recorder.onstop = () => {
      const parts = ultronSpeechRecorderParts;
      ultronSpeechRecorderParts = [];
      if (ultronSpeechRecorder === recorder) ultronSpeechRecorder = null;
      const discard = ultronDiscardSpeechSegment;
      ultronDiscardSpeechSegment = false;
      const audio = new Blob(parts, { type: recorder.mimeType || mimeType || 'audio/webm' });
      if (!discard && calling && !ultronCallSpeaking && audio.size >= 1200) {
        ultronSpeechRequestQueue.push(audio);
        void ultronDrainSpeechQueue();
      }
    };
    recorder.start();
    ultronSpeechStartedAt = performance.now();
    ultronSpeechLastVoiceAt = ultronSpeechStartedAt;
  } catch (error) {
    console.error('ULTRON Audioaufnahme:', error);
    ultronCallSignal('callSpeechSignal', 'Stimme: Audioaufnahme nicht verfügbar', 'bad');
  }
}

async function ultronDrainSpeechQueue() {
  if (ultronSpeechRequestActive || !ultronSpeechRequestQueue.length || !calling) return;
  ultronSpeechRequestActive = true;
  try {
    while (ultronSpeechRequestQueue.length && calling && !ultronCallSpeaking) {
      const blob = ultronSpeechRequestQueue.shift();
      await ultronTranscribeSpeechBlob(blob);
      if (ultronOnlineSpeechFailed) break;
    }
  } finally {
    ultronSpeechRequestActive = false;
  }
}

function ultronStartOnlineRecognition(stream) {
  if (!ultronPollinationsKey()) {
    ultronRecognitionMode = 'blocked';
    ultronSetSpeechSetupVisible(true);
    ultronCallSignal('callSpeechSignal', 'Stimme: Internet-Schlüssel fehlt', 'bad');
    ultronCallStatus('Kamera und Handsteuerung laufen. Die Spracheingabe braucht hier einen Pollinations-Schlüssel; der lokale Mikrofontest allein wandelt Ton nicht in Text um. Tippe auf „Spracherkennung einrichten“.');
    return false;
  }
  ultronSetSpeechSetupVisible(false);
  if (!window.MediaRecorder || !window.AudioContext && !window.webkitAudioContext) {
    ultronRecognitionMode = 'blocked';
    ultronCallSignal('callSpeechSignal', 'Stimme: Browser-Funktion fehlt', 'bad');
    ultronCallStatus('Die Audioaufnahme für Online-Spracherkennung wird von dieser Chromium-Version nicht unterstützt.');
    return false;
  }
  ultronStopOnlineRecognition(true);
  ultronOnlineSpeechFailed = false;
  ultronRecognitionMode = 'pollinations';
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    ultronAudioContext = new AudioContextClass();
    ultronAudioAnalyser = ultronAudioContext.createAnalyser();
    ultronAudioAnalyser.fftSize = 512;
    ultronAudioSource = ultronAudioContext.createMediaStreamSource(new MediaStream(stream.getAudioTracks()));
    ultronAudioSource.connect(ultronAudioAnalyser);
    ultronAudioSilentGain = ultronAudioContext.createGain();
    ultronAudioSilentGain.gain.value = 0;
    ultronAudioAnalyser.connect(ultronAudioSilentGain);
    ultronAudioSilentGain.connect(ultronAudioContext.destination);
    void ultronAudioContext.resume().catch(() => {});
    ultronCallSignal('callSpeechSignal', 'Stimme: wartet auf Sprache', 'good');
    ultronCallStatus('Mikrofon aktiv. ULTRON sendet nur erkannte Sprachabschnitte zur Transkription an Pollinations.');
    const meter = () => {
      if (!calling || ultronRecognitionMode !== 'pollinations' || !ultronAudioAnalyser) return;
      if (!ultronCallSpeaking) {
        const samples = new Float32Array(ultronAudioAnalyser.fftSize);
        ultronAudioAnalyser.getFloatTimeDomainData(samples);
        let energy = 0;
        for (let i = 0; i < samples.length; i++) energy += samples[i] * samples[i];
        const level = Math.sqrt(energy / samples.length);
        const now = performance.now();
        if (!ultronSpeechRecorder) {
          const threshold = Math.max(0.0048, ultronSpeechNoiseFloor * 2.7);
          if (level < threshold * 1.15) ultronSpeechNoiseFloor = ultronSpeechNoiseFloor * 0.92 + level * 0.08;
          if (level > threshold) {
            if (!ultronSpeechCandidateAt) ultronSpeechCandidateAt = now;
            if (now - ultronSpeechCandidateAt >= 100) {
              ultronStartSpeechSegment();
              ultronSpeechLastVoiceAt = now;
              ultronCallSignal('callSpeechSignal', 'Stimme: ich höre zu', 'busy');
            }
          } else {
            ultronSpeechCandidateAt = 0;
          }
        } else if (level > Math.max(0.004, ultronSpeechNoiseFloor * 1.9)) {
          ultronSpeechLastVoiceAt = now;
          ultronCallSignal('callSpeechSignal', 'Stimme: ich höre zu', 'busy');
        }
        if (ultronSpeechRecorder && (now - ultronSpeechLastVoiceAt > 1000 || now - ultronSpeechStartedAt > 15000)) {
          ultronStopSpeechSegment(false);
          ultronSpeechCandidateAt = 0;
        }
      }
      ultronAudioMeterTimer = setTimeout(meter, 110);
    };
    meter();
    return true;
  } catch (error) {
    ultronRecognitionMode = 'blocked';
    ultronStopOnlineRecognition(true);
    ultronCallSignal('callSpeechSignal', 'Stimme: Mikrofonmessung fehlgeschlagen', 'bad');
    ultronCallStatus('Online-Spracherkennung konnte nicht gestartet werden: ' + (error.message || error));
    return false;
  }
}

function ultronUseLocalRecognition(rec, reason) {
  if (!calling || ultronRecognitionMode !== 'native') return;
  ultronRecognitionMode = 'switching';
  ultronCallSignal('callSpeechSignal', 'Stimme: wechsle zur lokalen Erkennung', 'busy');
  if (recognition === rec) recognition = null;
  rec.onend = null;
  try { rec.stop(); } catch (_) {}
  ultronCallStatus('Chromium-Spracherkennung ist ausgefallen (' + reason + '). ULTRON startet die deutsche Offline-Erkennung.');
  void ultronStartLocalRecognition(ultronCallStream);
}

async function ultronStartLocalRecognition(stream) {
  if (!calling || !stream || !stream.getAudioTracks().some(track => track.readyState === 'live')) return false;
  ultronRecognitionMode = 'local-loading';
  ultronSetSpeechSetupVisible(false);
  ultronCallSignal('callSpeechSignal', 'Stimme: deutsches Offline-Modell wird geladen …', 'busy');
  ultronCallStatus('ULTRON lädt die deutsche Offline-Spracherkennung. Beim ersten Start kann das einige Sekunden dauern. Deine Mikrofonaufnahme bleibt auf diesem Gerät.');
  let recognizer = null;
  let context = null;
  try {
    if (typeof window.ultronCreateVoskClient !== 'function') throw new Error('Offline-Sprachmodell nicht in der App gefunden.');
    if (!ultronVoskClient) ultronVoskClient = await window.ultronCreateVoskClient();
    if (!calling || stream !== ultronCallStream) return false;
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass || !window.MediaStream) throw new Error('Audioverarbeitung wird von dieser App-Version nicht unterstützt.');
    context = new AudioContextClass({ sampleRate: 16000 });
    await context.resume();
    if (!calling || stream !== ultronCallStream) {
      context.close().catch(() => {});
      return false;
    }
    if (context.state !== 'running') throw new Error('Der Audio-Kontext konnte nicht gestartet werden.');
    // Chromium can ignore the requested AudioContext sample rate. Vosk's
    // worker recreates a recognizer whenever chunk and recognizer rates differ;
    // using the actual rate prevents it from resetting on every audio block.
    const inputSampleRate = context.sampleRate;
    recognizer = new ultronVoskClient.KaldiRecognizer(inputSampleRate);
    recognizer.on('partialresult', message => {
      if (!calling || ultronRecognitionMode !== 'local' || ultronCallSpeaking) return;
      const partial = String(message?.result?.partial || '').trim();
      if (partial.length < 3 || partial === ultronCallPartialText) return;
      ultronCallPartialText = partial;
      clearTimeout(ultronCallPartialTimer);
      ultronCallPartialTimer = setTimeout(() => {
        if (!calling || ultronRecognitionMode !== 'local' || ultronCallSpeaking || partial !== ultronCallPartialText) return;
        ultronUpdateCallTopic(partial, '', true);
        ultronCallSignal('callSpeechSignal', 'Stimme: ' + ultronTrimCallText(partial, 34), 'busy');
      }, 220);
    });
    recognizer.on('result', message => {
      if (!calling || ultronRecognitionMode !== 'local' || ultronCallSpeaking) return;
      clearTimeout(ultronCallPartialTimer);
      ultronCallPartialText = '';
      const heard = String(message?.result?.text || '').trim();
      if (heard) {
        ultronQueueCallTranscript(heard);
        if (calling) ultronCallSignal('callSpeechSignal', 'Stimme: verstanden · offline', 'good');
      }
    });
    recognizer.on('error', message => {
      console.warn('ULTRON lokale Spracherkennung:', message?.error || message);
    });
    ultronLocalAudioSource = context.createMediaStreamSource(new MediaStream(stream.getAudioTracks()));
    ultronLocalAudioHighpass = context.createBiquadFilter();
    ultronLocalAudioHighpass.type = 'highpass';
    ultronLocalAudioHighpass.frequency.value = 85;
    ultronLocalAudioHighpass.Q.value = 0.707;
    ultronLocalAudioGain = context.createGain();
    ultronLocalAudioGain.gain.value = 1.8;
    ultronLocalAudioCompressor = context.createDynamicsCompressor();
    ultronLocalAudioCompressor.threshold.value = -34;
    ultronLocalAudioCompressor.knee.value = 18;
    ultronLocalAudioCompressor.ratio.value = 2.5;
    ultronLocalAudioCompressor.attack.value = 0.005;
    ultronLocalAudioCompressor.release.value = 0.24;
    ultronLocalAudioProcessor = context.createScriptProcessor(4096, 1, 1);
    ultronLocalAudioMute = context.createGain();
    ultronLocalAudioMute.gain.value = 0;
    ultronLocalAudioProcessor.onaudioprocess = event => {
      if (!calling || ultronRecognitionMode !== 'local' || ultronCallSpeaking || !ultronVoskRecognizer) return;
      try { ultronVoskRecognizer.acceptWaveform(event.inputBuffer); }
      catch (error) { console.warn('ULTRON Audio an Vosk:', error); }
    };
    ultronLocalAudioSource.connect(ultronLocalAudioHighpass);
    ultronLocalAudioHighpass.connect(ultronLocalAudioGain);
    ultronLocalAudioGain.connect(ultronLocalAudioCompressor);
    ultronLocalAudioCompressor.connect(ultronLocalAudioProcessor);
    ultronLocalAudioProcessor.connect(ultronLocalAudioMute);
    ultronLocalAudioMute.connect(context.destination);
    ultronVoskRecognizer = recognizer;
    ultronLocalAudioContext = context;
    recognizer = null;
    context = null;
    ultronRecognitionMode = 'local';
    ultronCallSignal('callSpeechSignal', 'Stimme: deutsch · offline bereit', 'good');
    ultronCallStatus('Ich höre zu. Die deutsche Spracherkennung und das Mikrofon bleiben lokal auf diesem Gerät.');
    return true;
  } catch (error) {
    if (recognizer) { try { recognizer.remove(); } catch (_) {} }
    if (context) context.close().catch(() => {});
    ultronStopLocalRecognition();
    if (!calling) return false;
    const reason = error?.message || 'unbekannter Fehler';
    // The standalone Linux app ships Vosk locally. Never switch its microphone
    // transcription to an online service when local loading fails.
    if (!window.ultronDesktop && ultronPollinationsKey()) return ultronStartOnlineRecognition(stream);
    ultronRecognitionMode = 'blocked';
    ultronSetSpeechSetupVisible(true);
    ultronCallSignal('callSpeechSignal', 'Stimme: Offline-Erkennung fehlgeschlagen', 'bad');
    ultronCallStatus('Die lokale deutsche Spracherkennung konnte nicht starten: ' + reason + '. Prüfe, ob das App-Paket vollständig entpackt wurde.');
    return false;
  }
}

function ultronStartRecognition(stream) {
  // Prefer accurate Whisper transcription only after the user has entered a
  // Pollinations key; otherwise keep the bundled German Vosk path fully local.
  if (window.ultronDesktop) {
    ultronRecognitionBlocked = false;
    ultronRecognitionRetryDelay = 700;
    if (ultronPollinationsKey()) {
      ultronCallSignal('callSpeechSignal', 'Stimme: Whisper für höhere Genauigkeit', 'busy');
      if (!ultronStartOnlineRecognition(stream)) void ultronStartLocalRecognition(stream);
    } else {
      void ultronStartLocalRecognition(stream);
    }
    return true;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { void ultronStartLocalRecognition(stream); return true; }
  ultronRecognitionBlocked = false;
  ultronRecognitionRetryDelay = 700;
  ultronRecognitionMode = 'native';
  const rec = new SR();
  recognition = rec;
  rec.lang = 'de-DE';
  rec.continuous = true;
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  rec.onstart = () => {
    ultronRecognitionRetryDelay = 700;
    ultronSetSpeechSetupVisible(false);
    if (calling && !ultronCallSpeaking) {
      ultronCallStatus(ultronCallCameraReady
        ? '● Ich höre zu. Sprich mit mir. Die Kamera ist aktiv.'
        : '● Ich höre zu. Sprich mit mir. Die Kamera ist nicht verfügbar.');
      ultronCallSignal('callSpeechSignal', 'Stimme: Chromium-Erkennung bereit', 'good');
    }
  };
  rec.onerror = event => {
    const error = event && event.error ? event.error : 'unbekannt';
    if (error === 'network' || error === 'not-allowed' || error === 'service-not-allowed') {
      ultronRecognitionRetryDelay = 3500;
      ultronCallSignal('callSpeechSignal', 'Stimme: Chromium-Dienst nicht erreichbar', 'busy');
      ultronUseLocalRecognition(rec, error);
    } else if (error !== 'no-speech' && error !== 'aborted') {
      ultronCallStatus('Spracherkennung: ' + error + '. Ich versuche es erneut.');
    }
  };
  rec.onresult = event => {
    let heard = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) heard += (heard ? ' ' : '') + event.results[i][0].transcript;
    }
    heard = heard.trim();
    if (heard && ultronRecognitionMode === 'native') ultronQueueCallTranscript(heard);
  };
  rec.onend = () => {
    if (calling && !ultronCallSpeaking && !ultronRecognitionBlocked && recognition === rec && ultronRecognitionMode === 'native') {
      ultronRestartRecognition(ultronRecognitionRetryDelay);
    }
  };
  try { rec.start(); return true; }
  catch (_) {
    recognition = null;
    void ultronStartLocalRecognition(stream);
    return true;
  }
}

// Pause the recognizer while the assistant speaks so it does not transcribe its own voice.
window.ultronBeforeSpeak = () => {
  if (!calling) return;
  ultronCallSpeaking = true;
  ultronSpeechCandidateAt = 0;
  ultronCallSignal('callAISignal', 'ULTRON spricht', 'busy');
  ultronCallStatus('ULTRON antwortet gerade mit Stimme …');
  clearTimeout(ultronRecognitionTimer);
  if (recognition && ultronRecognitionMode === 'native') {
    try { recognition.stop(); } catch (_) {}
  }
  if (ultronRecognitionMode === 'local') ultronCallSignal('callSpeechSignal', 'Stimme: kurze Sprechpause', 'busy');
  if (ultronRecognitionMode === 'pollinations') ultronStopSpeechSegment(true);
};
window.ultronAfterSpeak = () => {
  ultronCallSpeaking = false;
  if (!calling) return;
  ultronCallSignal('callAISignal', 'ULTRON: bereit', 'good');
  if (ultronRecognitionMode === 'native' || ultronRecognitionMode === 'pollinations' || ultronRecognitionMode === 'local') {
    ultronCallSignal('callSpeechSignal', ultronRecognitionMode === 'native' ? 'Stimme: Chromium-Erkennung bereit' : ultronRecognitionMode === 'local' ? 'Stimme: deutsch · offline bereit' : 'Stimme: wartet auf Sprache', 'good');
    ultronCallStatus('Ich höre zu. Sprich mit mir.');
  } else {
    ultronCallStatus('Antwort gesprochen. Die Spracheingabe ist noch nicht eingerichtet.');
  }
  if (calling && ultronRecognitionMode === 'native') ultronRestartRecognition(400);
  if (calling && ultronRecognitionMode === 'local') ultronCallStatus('Ich höre zu. Deine Sprache bleibt auf diesem Gerät.');
  if (calling && ultronRecognitionMode === 'pollinations') {
    ultronCallSignal('callSpeechSignal', 'Stimme: wartet auf Sprache', 'good');
    void ultronDrainSpeechQueue();
  }
};

async function ultronStartHandTracking() {
  const status = document.getElementById('callStatus');
  try {
    if (!window.ultronVisionModule) {
      window.ultronVisionModule = import(new URL('./vendor/mediapipe/vision_bundle.mjs', location.href).href);
    }
    const vision = await window.ultronVisionModule;
    const wasmRoot = new URL('./vendor/mediapipe/wasm/', location.href).href;
    const files = await vision.FilesetResolver.forVisionTasks(wasmRoot);
    const model = new URL('./models/hand_landmarker.task', location.href).href;
    const common = {
      runningMode: 'VIDEO',
      numHands: 1,
      minHandDetectionConfidence: 0.5,
      minHandPresenceConfidence: 0.45,
      minTrackingConfidence: 0.45
    };
    try {
      ultronHandLandmarker = await vision.HandLandmarker.createFromOptions(files, {
        ...common, baseOptions: { modelAssetPath: model, delegate: 'GPU' }
      });
    } catch (_) {
      ultronHandLandmarker = await vision.HandLandmarker.createFromOptions(files, {
        ...common, baseOptions: { modelAssetPath: model, delegate: 'CPU' }
      });
    }
    if (!calling) {
      ultronHandLandmarker.close();
      ultronHandLandmarker = null;
      return;
    }
    ultronLastVideoTime = -1;
    ultronLastDetectionAt = 0;
    document.getElementById('voicePanel')?.classList.add('hand-ready');
    ultronCallSignal('callHandSignal', 'Hand: bereit · zum Greifen kneifen', 'good');
    if (status) status.textContent = 'Handsteuerung bereit. Daumen und Zeigefinger zusammenhalten und die Hand bewegen, um den Ring zu ziehen.';
    ultronRunHandTracking();
  } catch (error) {
    console.warn('ULTRON Handsteuerung konnte nicht starten:', error);
    window.ultronVisionModule = null;
    ultronCallSignal('callHandSignal', 'Hand: nicht verfügbar', 'bad');
    if (calling && status) {
      status.textContent = location.protocol === 'file:'
        ? 'Die Dateivorschau blockiert Handtracking. Starte ULTRON über das Mint-Startmenü oder „ultron-starten“. '
        : 'Handerkennung nicht bereit; bewege den Ring mit Maus oder Touch.';
    }
  }
}
function ultronHandHitOrbitCard() {
  const stage = document.getElementById('callStage');
  const cursor = ultronHandCursor;
  if (!stage || !cursor) return false;
  const bounds = stage.getBoundingClientRect();
  const x = bounds.left + cursor.x * bounds.width;
  const y = bounds.top + cursor.y * bounds.height;
  const cards = Array.from(document.querySelectorAll('#callOrbitImages .call-orbit-image'));
  const hit = cards.find(card => {
    const rect = card.getBoundingClientRect();
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  });
  cards.forEach(card => card.classList.toggle('hand-hover', card === hit));
  if (hit) {
    hit.click();
    ultronCallSignal('callHandSignal', 'Hand: Info ausgewählt', 'good', hit.title || '');
    return true;
  }
  return false;
}

function ultronRunHandTracking() {
  if (!calling || !ultronHandLandmarker) return;
  const video = document.getElementById('callVideo');
  const now = performance.now();
  if (video && video.readyState >= 2 && video.currentTime !== ultronLastVideoTime && now - ultronLastDetectionAt > 45) {
    try {
      const result = ultronHandLandmarker.detectForVideo(video, now);
      ultronLastVideoTime = video.currentTime;
      ultronLastDetectionAt = now;
      if (result.landmarks && result.landmarks.length) {
        const landmarks = result.landmarks[0];
        const tip = landmarks[8];
        const raw = { x: 1 - tip.x, y: tip.y };
        if (!ultronLastHandSeenAt || !ultronHandFiltered) {
          ultronHandAnchor = null;
          ultronHandFiltered = raw;
        } else {
          const filter = 0.42;
          ultronHandFiltered = {
            x: ultronHandFiltered.x + (raw.x - ultronHandFiltered.x) * filter,
            y: ultronHandFiltered.y + (raw.y - ultronHandFiltered.y) * filter
          };
        }
        ultronHandRaw = raw;
        const palmWidth = Math.max(Math.hypot(landmarks[5].x - landmarks[17].x, landmarks[5].y - landmarks[17].y), 0.04);
        const pinchRatio = Math.hypot(landmarks[4].x - landmarks[8].x, landmarks[4].y - landmarks[8].y) / palmWidth;
        const wasPinching = ultronHandPinching;
        // Separate thresholds prevent flicker while the thumb and index finger
        // hover near each other, like the pinch/grab gesture used by Quest.
        ultronHandPinching = wasPinching ? pinchRatio < 0.48 : pinchRatio < 0.32;
        ultronHandCursor = {
          x: Math.max(0.04, Math.min(0.96, ultronHandFiltered.x)),
          y: Math.max(0.08, Math.min(0.88, ultronHandFiltered.y))
        };
        if (ultronHandPinching && !wasPinching) {
          const selectedOrbitCard = ultronHandHitOrbitCard();
          if (selectedOrbitCard) {
            // A pinch on a floating card selects it instead of grabbing the whole orbit.
            ultronHandAnchor = null;
            ultronHandTarget = null;
          } else {
            ultronHandAnchor = {
              x: ultronHandFiltered.x,
              y: ultronHandFiltered.y,
              pointerX: ultronPointer.x,
              pointerY: ultronPointer.y
            };
            ultronCallSignal('callHandSignal', 'Hand: Ring gegriffen · bewege die Hand', 'good');
          }
        } else if (!ultronHandPinching && wasPinching) {
          ultronHandAnchor = null;
          ultronHandTarget = null;
          ultronCallSignal('callHandSignal', 'Hand: Ring losgelassen', 'good');
        } else if (!wasPinching && !ultronLastHandSeenAt) {
          ultronCallSignal('callHandSignal', 'Hand: erkannt · Daumen und Zeigefinger kneifen', 'good');
        }
        if (ultronHandPinching && ultronHandAnchor) {
          const deadZone = value => Math.sign(value) * Math.max(0, Math.abs(value) - 0.008) / 0.992;
          const scale = 2.15;
          ultronHandTarget = {
            x: Math.max(0, Math.min(1, ultronHandAnchor.pointerX + deadZone(ultronHandFiltered.x - ultronHandAnchor.x) * scale)),
            y: Math.max(0, Math.min(1, ultronHandAnchor.pointerY + deadZone(ultronHandFiltered.y - ultronHandAnchor.y) * scale))
          };
        } else {
          ultronHandTarget = null;
        }
        ultronHandPoint = ultronHandCursor;
        ultronHandHitOrbitCard();
        ultronLastHandSeenAt = now;
        document.getElementById('voicePanel')?.classList.add('hand-ready');
      } else if (ultronLastHandSeenAt && now - ultronLastHandSeenAt > 450) {
        ultronHandPoint = null;
        ultronHandTarget = null;
        ultronHandCursor = null;
        ultronHandAnchor = null;
        ultronHandFiltered = null;
        ultronHandRaw = null;
        ultronHandPinching = false;
        document.querySelectorAll('#callOrbitImages .call-orbit-image.hand-hover').forEach(card => card.classList.remove('hand-hover'));
        ultronLastHandSeenAt = 0;
        ultronCallSignal('callHandSignal', 'Hand: nicht erkannt', 'neutral');
        document.getElementById('voicePanel')?.classList.remove('hand-ready');
      }
    } catch (error) {
      console.warn('ULTRON Handtracking-Frame:', error);
    }
  }
  ultronHandRaf = requestAnimationFrame(ultronRunHandTracking);
}

function ultronStartOrb() {
  const canvas = document.getElementById('ultronOrbitCanvas');
  if (!canvas || ultronOrbitRaf) return;
  const context = canvas.getContext('2d');
  if (!context) {
    ultronCallStatus('Die 3D-Call-Animation kann in dieser Umgebung nicht angezeigt werden. Kamera und Sprache können weiterlaufen.');
    return;
  }
  const nodes = [
    { name: 'STIMME', color: '#ffc45e' },
    { name: 'KAMERA', color: '#83d7ff' },
    { name: 'MIKROFON', color: '#68e5a0' },
    { name: 'HANDSTEUERUNG', color: '#ff9c5c' }
  ];
  function draw() {
    const frameNow = performance.now();
    const deltaSeconds = ultronOrbitLastFrame ? Math.min(0.05, (frameNow - ultronOrbitLastFrame) / 1000) : 1 / 60;
    ultronOrbitLastFrame = frameNow;
    const bounds = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(bounds.width * dpr));
    const height = Math.max(1, Math.round(bounds.height * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    const w = bounds.width, h = bounds.height, time = frameNow / 1000;
    context.clearRect(0, 0, w, h);
    if (!w || !h) {
      ultronOrbitRaf = requestAnimationFrame(draw);
      return;
    }
    for (let index = 0; index < 28; index++) {
      const starX = ((index * 0.61803398875) % 1) * w;
      const starY = ((index * 0.75487766625 + 0.17) % 1) * h;
      const twinkle = 0.18 + 0.48 * (0.5 + 0.5 * Math.sin(time * (0.6 + index % 4 * 0.18) + index * 2.1));
      context.beginPath();
      context.arc(starX, starY, index % 9 === 0 ? 1.15 : 0.7, 0, Math.PI * 2);
      context.fillStyle = 'rgba(255, 211, 145,' + twinkle.toFixed(3) + ')';
      context.fill();
    }
    if (ultronHandTarget) {
      const dx = ultronHandTarget.x - ultronPointer.x;
      const dy = ultronHandTarget.y - ultronPointer.y;
      const follow = 1 - Math.exp(-deltaSeconds * 11);
      if (Math.abs(dx) > 0.002) ultronPointer.x += dx * follow;
      if (Math.abs(dy) > 0.002) ultronPointer.y += dy * follow;
    }
    const cx = w * 0.5;
    const cy = h * (0.5 + (ultronPointer.y - 0.5) * 0.12);
    const rx = Math.min(w * 0.36, 245) * (1 + (0.5 - ultronPointer.y) * 0.16);
    const ry = Math.min(h * 0.32, 180);
    const targetAngle = (ultronPointer.x - 0.5) * Math.PI * 1.45;
    const angleFollow = 1 - Math.exp(-deltaSeconds * 3.4);
    ultronOrbitAngle += (targetAngle - ultronOrbitAngle) * angleFollow + deltaSeconds * 0.12;
    ultronOrbitTilt += ((ultronPointer.y - 0.5) * 1.4 - ultronOrbitTilt) * (1 - Math.exp(-deltaSeconds * 3.8));

    const imageCards = document.getElementById('callOrbitImages')?.children;
    const imageCount = imageCards?.length || 0;
    const imageRotation = Math.sin(ultronOrbitTilt) * 0.28;
    for (let index = 0; index < imageCount; index++) {
      const angle = ultronOrbitAngle + index * Math.PI * 2 / imageCount - time * 0.17;
      const localX = Math.cos(angle) * rx * 0.64;
      const localY = Math.sin(angle) * ry * 0.62;
      const imageX = cx + localX * Math.cos(imageRotation) - localY * Math.sin(imageRotation);
      const imageY = cy + localX * Math.sin(imageRotation) + localY * Math.cos(imageRotation);
      const depth = 0.8 + (Math.sin(angle) + 1) * 0.08;
      const card = imageCards[index];
      card.style.left = imageX + 'px';
      card.style.top = imageY + 'px';
      card.style.transform = 'translate(-50%,-50%) scale(' + depth.toFixed(3) + ')';
      card.style.zIndex = String(Math.round(depth * 10));
    }

    context.save();
    context.translate(cx, cy);
    context.rotate(Math.sin(ultronOrbitTilt) * 0.28);
    const halo = context.createRadialGradient(0, 0, 10, 0, 0, Math.max(rx, ry) * 1.35);
    halo.addColorStop(0, '#ff9d2424');
    halo.addColorStop(0.68, '#e66d160a');
    halo.addColorStop(1, '#00000000');
    context.fillStyle = halo;
    context.fillRect(-w, -h, w * 2, h * 2);

    context.beginPath();
    context.ellipse(0, 0, rx, ry, 0.03, 0, Math.PI * 2);
    context.strokeStyle = '#ffbf668e';
    context.lineWidth = 1.6;
    context.shadowBlur = 20;
    context.shadowColor = '#ff9d38';
    context.stroke();
    context.shadowBlur = 0;
    context.beginPath();
    context.ellipse(0, 0, rx * 0.82, ry * 0.76, -0.09, 0, Math.PI * 2);
    context.strokeStyle = '#ff9d4d57';
    context.lineWidth = 1.1;
    context.setLineDash([5, 10]);
    context.stroke();
    context.setLineDash([]);

    context.save();
    context.lineCap = 'round';
    context.strokeStyle = '#ffc46b75';
    context.lineWidth = 2;
    context.shadowBlur = 10;
    context.shadowColor = '#ff8c2c';
    for (let index = 0; index < 8; index++) {
      const start = time * 0.22 + index * Math.PI * 2 / 8;
      context.beginPath();
      context.ellipse(0, 0, rx * 0.72, ry * 0.62, 0.06, start, start + 0.16);
      context.stroke();
    }
    context.restore();

    for (let index = 0; index < 9; index++) {
      const angle = time * 0.18 + index * Math.PI * 2 / 9;
      const x = Math.cos(angle) * rx * 0.68;
      const y = Math.sin(angle) * ry * 0.57;
      const radius = 1 + (index % 3) * 0.45;
      context.beginPath();
      context.arc(x, y, radius + 2, 0, Math.PI * 2);
      context.fillStyle = '#ffb84a18';
      context.fill();
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.fillStyle = '#ffd48b';
      context.shadowBlur = 9;
      context.shadowColor = '#ff9d38';
      context.fill();
      context.shadowBlur = 0;
    }

    const aiState = document.getElementById('callAISignal')?.dataset.state;
    const thinking = calling && !ultronCallSpeaking && aiState === 'busy';
    const idleBreath = 0.5 + 0.5 * Math.sin(time * 1.35);
    const speakingPulse = ultronCallSpeaking ? 0.66 + 0.22 * (0.5 + 0.5 * Math.sin(time * 4.5)) : 0;
    const thinkingPulse = thinking ? 0.2 + 0.12 * (0.5 + 0.5 * Math.sin(time * 2.6)) : 0;
    const voicePulse = Math.max(Math.min(1, ultronMicVisualLevel * 2.5), speakingPulse, thinkingPulse);
    const orbBaseRadius = Math.max(34, Math.min(58, w * 0.105));
    const orbRadius = orbBaseRadius * (1 + idleBreath * 0.025 + voicePulse * (ultronCallSpeaking ? 0.09 : 0.045));
    const orbMidColor = ultronCallSpeaking ? '#fff0ad' : thinking ? '#ffd880' : '#ffc255';
    const orbEdgeColor = ultronCallSpeaking ? '#ff7525' : thinking ? '#e66b19' : '#b83f12';
    context.beginPath();
    context.arc(0, 0, orbRadius + 24 + Math.sin(time * 2) * 3, 0, Math.PI * 2);
    context.fillStyle = '#ff9b2620';
    context.fill();
    const aura = context.createRadialGradient(0, 0, orbRadius * 0.25, 0, 0, orbRadius * 1.55);
    aura.addColorStop(0, '#ffe7a43b');
    aura.addColorStop(0.62, '#ff8e2530');
    aura.addColorStop(1, '#ff5b1200');
    context.beginPath();
    context.arc(0, 0, orbRadius * 1.55, 0, Math.PI * 2);
    context.fillStyle = aura;
    context.fill();

    context.save();
    context.rotate(time * 0.36);
    context.beginPath();
    context.ellipse(0, 0, orbRadius * 1.32, orbRadius * 0.42, 0, Math.PI * 1.02, Math.PI * 1.98);
    context.strokeStyle = '#ffd27bda';
    context.lineWidth = 2;
    context.shadowBlur = 16;
    context.shadowColor = '#ff8c2c';
    context.stroke();
    context.restore();

    const orb = context.createRadialGradient(-orbRadius * 0.35, -orbRadius * 0.45, 2, 0, 0, orbRadius * 1.4);
    orb.addColorStop(0, '#fffdf0');
    orb.addColorStop(0.12, '#fff2b0');
    orb.addColorStop(0.38, orbMidColor);
    orb.addColorStop(0.7, orbEdgeColor);
    orb.addColorStop(1, '#311307');
    context.beginPath();
    context.arc(0, 0, orbRadius, 0, Math.PI * 2);
    context.fillStyle = orb;
    context.shadowBlur = 48 + idleBreath * 12 + voicePulse * 24;
    context.shadowColor = '#ff8f2b';
    context.fill();
    context.shadowBlur = 0;

    context.save();
    context.beginPath();
    context.arc(0, 0, orbRadius * 0.97, 0, Math.PI * 2);
    context.clip();
    context.globalAlpha = 0.21;
    context.strokeStyle = '#fff1bd';
    context.lineWidth = 1;
    for (let index = 0; index < 9; index++) {
      const angle = index * Math.PI / 9 + time * 0.08;
      context.beginPath();
      context.moveTo(Math.cos(angle) * orbRadius * 0.36, Math.sin(angle) * orbRadius * 0.36);
      context.lineTo(Math.cos(angle) * orbRadius * 0.9, Math.sin(angle) * orbRadius * 0.9);
      context.stroke();
    }
    context.restore();

    context.beginPath();
    context.arc(0, 0, orbRadius + 7, 0, Math.PI * 2);
    context.strokeStyle = '#ffe3a5c9';
    context.lineWidth = 1;
    context.stroke();

    context.save();
    context.rotate(-time * 0.28);
    context.beginPath();
    context.ellipse(0, 0, orbRadius * 1.22, orbRadius * 0.38, 0, 0.06, Math.PI - 0.06);
    context.strokeStyle = '#ff9b4cbd';
    context.lineWidth = 2.2;
    context.shadowBlur = 11;
    context.shadowColor = '#ff7e27';
    context.stroke();
    context.restore();

    context.textAlign = 'center';
    context.fillStyle = '#2a1208';
    context.font = '700 ' + Math.max(11, orbRadius * 0.32) + 'px system-ui';
    context.fillText('ULTRON', 0, 4);
    context.fillStyle = '#ffe3b2';
    context.font = '10px system-ui';
    context.fillText(ultronCallSpeaking ? 'SPRICHT' : thinking ? 'ANTWORTET' : calling ? 'HÖRT ZU' : 'BEREIT', 0, orbRadius + 22);
    if (ultronCallTopicText) {
      context.fillStyle = '#ffcf83';
      context.font = '700 10px system-ui';
      context.fillText('GESPRÄCH · ' + ultronTrimCallText(ultronCallTopicText, 42), 0, -ry * 0.72, Math.max(120, rx * 1.55));
    }

    nodes.forEach((node, index) => {
      const angle = ultronOrbitAngle + index * Math.PI * 2 / nodes.length + time * 0.13;
      const x = Math.cos(angle) * rx, y = Math.sin(angle) * ry;
      const active = index === 0
        ? document.getElementById('callSpeechSignal')?.dataset.state === 'busy'
        : index === 1 ? ultronCallCameraReady
          : index === 2 ? voicePulse > 0.08
            : !!ultronHandPoint;
      const pulse = active ? 1 + 0.28 * (0.5 + 0.5 * Math.sin(time * 5 + index)) : 1;
      const depth = 0.62 + (Math.sin(angle) + 1) * 0.19, radius = 5 * depth * pulse;
      context.beginPath();
      context.arc(x, y, radius + 7, 0, Math.PI * 2);
      context.fillStyle = node.color + '25';
      context.fill();
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.fillStyle = node.color;
      context.shadowBlur = active ? 22 : 14;
      context.shadowColor = node.color;
      context.fill();
      context.shadowBlur = 0;
      context.font = '600 ' + Math.max(9, 10 * depth) + 'px system-ui';
      context.textAlign = 'center';
      context.fillStyle = '#d7e8f6';
      context.fillText(node.name, x, y - 14);
    });
    if (ultronHandPoint) {
      const hx = ultronHandCursor.x * w, hy = ultronHandCursor.y * h;
      const cursorRadius = ultronHandPinching ? 13 : 8;
      context.beginPath();
      context.arc(hx, hy, cursorRadius + (ultronHandPinching ? Math.sin(time * 10) * 2 : 0), 0, Math.PI * 2);
      context.strokeStyle = ultronHandPinching ? '#78e1b1' : '#ffffffbb';
      context.lineWidth = ultronHandPinching ? 2 : 1.5;
      context.shadowBlur = 12;
      context.shadowColor = ultronHandPinching ? '#55e5a2' : '#79e7ff';
      context.stroke();
      context.shadowBlur = 0;
      context.font = '600 9px system-ui';
      context.textAlign = 'center';
      context.fillStyle = ultronHandPinching ? '#8df3c1' : '#d7e8f6';
      context.fillText(ultronHandPinching ? 'GREIFEN' : 'PINCH', hx, hy - 16);
    }
    context.restore();
    ultronOrbitRaf = requestAnimationFrame(draw);
  }
  canvas.addEventListener('pointermove', event => {
    if (ultronHandPoint) return;
    const bounds = canvas.getBoundingClientRect();
    ultronPointer = {
      x: Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width)),
      y: Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height))
    };
  });
  canvas.addEventListener('pointerleave', () => {
    if (!ultronHandPoint) ultronPointer = { x: 0.5, y: 0.5 };
  });
  document.getElementById('handRecenter')?.addEventListener('click', () => {
    ultronPointer = { x: 0.5, y: 0.5 };
    ultronHandAnchor = null;
    ultronHandPinching = false;
    ultronHandTarget = null;
    ultronHandFiltered = ultronHandRaw;
    ultronHandTarget = { x: 0.5, y: 0.5 };
    ultronOrbitAngle = 0;
    ultronOrbitTilt = 0;
  });
  draw();
}

async function ultronAcquireCallMedia() {
  const audio = { echoCancellation: true, noiseSuppression: true, autoGainControl: true };
  const video = { width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 } };
  try {
    return { stream: await navigator.mediaDevices.getUserMedia({ audio, video }), cameraError: null, micError: null };
  } catch (combinedError) {
    if (['NotAllowedError', 'PermissionDeniedError', 'SecurityError'].includes(combinedError?.name)) throw combinedError;
    let cameraStream = null;
    let micStream = null;
    let cameraError = null;
    let micError = null;
    try { cameraStream = await navigator.mediaDevices.getUserMedia({ audio: false, video }); }
    catch (error) { cameraError = error; }
    try { micStream = await navigator.mediaDevices.getUserMedia({ audio, video: false }); }
    catch (error) { micError = error; }
    const tracks = [
      ...(cameraStream ? cameraStream.getVideoTracks() : []),
      ...(micStream ? micStream.getAudioTracks() : [])
    ];
    if (!tracks.length) {
      const details = [
        'Kamera: ' + (cameraError?.message || cameraError?.name || 'nicht verfügbar'),
        'Mikrofon: ' + (micError?.message || micError?.name || 'nicht verfügbar')
      ].join(' · ');
      const error = new Error(details);
      error.name = 'MediaStartError';
      throw error;
    }
    return { stream: new MediaStream(tracks), cameraError, micError };
  }
}

function ultronWaitForCameraFrame(video, timeoutMs = 6000) {
  const hasFrame = () => video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && video.videoWidth > 0 && video.videoHeight > 0;
  if (hasFrame()) return Promise.resolve(true);
  return new Promise(resolve => {
    let finished = false;
    const cleanup = () => {
      clearInterval(checkTimer);
      clearTimeout(timeoutTimer);
      video.removeEventListener('loadeddata', check);
      video.removeEventListener('playing', check);
    };
    const finish = ready => {
      if (finished) return;
      finished = true;
      cleanup();
      resolve(ready);
    };
    const check = () => { if (hasFrame()) finish(true); };
    const checkTimer = setInterval(check, 80);
    const timeoutTimer = setTimeout(() => finish(false), timeoutMs);
    video.addEventListener('loadeddata', check);
    video.addEventListener('playing', check);
    check();
  });
}

async function startCall() {
  if (calling || ultronCallStarting) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    ultronCallStatus('Kamera und Mikrofon sind in dieser Umgebung nicht verfügbar.');
    return;
  }
  const request = ++ultronCallRequest;
  ultronCallStarting = true;
  ultronCallSignal('callInternetSignal', navigator.onLine ? 'Internet: wird geprüft' : 'Internet: offline', navigator.onLine ? 'busy' : 'bad');
  ultronCallSignal('callSpeechSignal', 'Stimme: Mikrofon wird gestartet', 'busy');
  ultronCallSignal('callHandSignal', 'Hand: Kamera wird gestartet', 'busy');
  ultronCallSignal('callCameraSignal', 'Kamera: wird gestartet', 'busy');
  const modelMode = document.getElementById('ultronModelMode')?.value || 'auto';
  const hasApiKey = !!ultronPollinationsKey();
  const localModelReady = ultronHasLocalModel();
  const aiSetup = modelMode === 'online'
    ? (hasApiKey ? ['ULTRON: Online-KI bereit', 'good'] : ['ULTRON: API-Schlüssel fehlt', 'bad'])
    : modelMode === 'local'
      ? (localModelReady ? ['ULTRON: lokales Modell bereit', 'good'] : ['ULTRON: lokales Modell laden', 'bad'])
      : localModelReady
        ? ['ULTRON: lokales Modell bereit', 'good']
        : hasApiKey
          ? ['ULTRON: Online-Rückfall bereit', 'good']
          : ['ULTRON: Modell oder API-Schlüssel fehlt', 'bad'];
  ultronCallSignal('callAISignal', aiSetup[0], aiSetup[1]);
  void ultronCheckCallInternet();
  ultronCallStatus('Bitte erlaube Kamera und Mikrofon im ULTRON-Fenster …');
  try {
    const media = await ultronAcquireCallMedia();
    const stream = media.stream;
    if (request !== ultronCallRequest) {
      stream.getTracks().forEach(track => track.stop());
      return;
    }
    ultronCallStream = stream;
    const video = document.getElementById('callVideo');
    ultronCallMicReady = stream.getAudioTracks().some(track => track.readyState === 'live');
    ultronCallCameraReady = false;
    let cameraError = media.cameraError;
    if (video && stream.getVideoTracks().some(track => track.readyState === 'live')) {
      video.srcObject = stream;
      try {
        await video.play();
        ultronCallCameraReady = await ultronWaitForCameraFrame(video);
        if (!ultronCallCameraReady) cameraError = new Error('Kamera liefert kein Bild. Prüfe die Kamera und schließe andere Kamera-Apps.');
      } catch (error) {
        cameraError = error;
      }
    }
    if (ultronCallCameraReady) {
      ultronCallSignal('callCameraSignal', 'Kamera: Bild läuft', 'good');
    } else {
      const detail = cameraError?.message || cameraError?.name || 'Kein Kamerabild erhalten';
      ultronCallSignal('callCameraSignal', 'Kamera: ' + ultronCameraProblem(cameraError), 'bad', detail);
    }
    if (!ultronCallCameraReady) {
      stream.getVideoTracks().forEach(track => { track.stop(); stream.removeTrack(track); });
      if (video) video.srcObject = null;
      if (!ultronCallMicReady) {
        const error = new Error('Kamera oder Mikrofon konnte nicht gestartet werden. ' + (cameraError?.message || 'Kein Kamerabild erhalten.'));
        error.name = cameraError?.name || 'MediaStartError';
        throw error;
      }
    }
    ultronCallStarting = false;
    calling = true;
    document.getElementById('voicePanel')?.classList.add('call-active');
    const startButton = document.getElementById('voiceStart2');
    const stopButton = document.getElementById('voiceStop2');
    if (startButton) startButton.disabled = true;
    if (stopButton) stopButton.disabled = false;

    if (ultronCallMicReady) {
      void ultronStartMicMonitor(stream);
    } else {
      ultronCallSignal('callMicSignal', 'Mikrofon: nicht verfügbar', 'bad');
      ultronCallSignal('callSpeechSignal', 'Stimme: Mikrofon nicht verfügbar', 'bad');
    }
    const speechReady = ultronCallMicReady ? ultronStartRecognition(stream) : false;
    if (!speechReady && ultronCallMicReady) {
      const speechSignal = document.getElementById('callSpeechSignal')?.textContent || 'Spracherkennung nicht bereit';
      ultronCallStatus('Kamera und Handsteuerung laufen. Spracheingabe: ' + speechSignal + '.');
    } else if (!ultronCallMicReady) {
      ultronCallStatus('Kamera läuft. Das Mikrofon ist nicht verfügbar; prüfe die Linux-Toneinstellungen.');
    } else {
      ultronCallStatus('● Kamera läuft. Ich starte Mikrofon und Handsteuerung …');
    }
    if (ultronCallCameraReady) {
      ultronCallSignal('callHandSignal', 'Hand: wird geladen', 'busy');
      void ultronStartHandTracking();
    } else {
      ultronCallSignal('callHandSignal', 'Hand: Kamera nicht verfügbar', 'bad');
      ultronCallStatus('Call läuft nur mit Mikrofon. Kamerafehler: ' + (cameraError?.message || cameraError?.name || 'Kein Kamerabild erhalten.'));
    }
    stream.getVideoTracks().forEach(track => track.addEventListener('ended', () => {
      if (calling) {
        ultronCallSignal('callCameraSignal', 'Kamera: Verbindung beendet', 'bad');
        ultronCallStatus('Kamera wurde beendet. Starte den Call erneut, um weiterzumachen.');
      }
    }));
    stream.getAudioTracks().forEach(track => track.addEventListener('ended', () => {
      if (calling) {
        ultronCallSignal('callMicSignal', 'Mikrofon: Verbindung beendet', 'bad');
        ultronCallSignal('callSpeechSignal', 'Stimme: Mikrofon wurde beendet', 'bad');
        ultronCallStatus('Das Mikrofon wurde beendet. Starte den Call erneut.');
      }
    }));
  } catch (error) {
    ultronCallStarting = false;
    ultronCallCameraReady = false;
    ultronCallMicReady = false;
    if (ultronCallStream) {
      ultronCallStream.getTracks().forEach(track => track.stop());
      ultronCallStream = null;
    }
    const video = document.getElementById('callVideo');
    if (video) video.srcObject = null;
    const startButton = document.getElementById('voiceStart2');
    const stopButton = document.getElementById('voiceStop2');
    if (startButton) startButton.disabled = false;
    if (stopButton) stopButton.disabled = true;
    ultronCallSignal('callHandSignal', 'Hand: Call nicht gestartet', 'bad');
    ultronCallSignal('callCameraSignal', 'Kamera: ' + ultronCameraProblem(error), 'bad', error.message || error.name || 'Unbekannter Fehler');
    let reason = error.message || error.name || 'unbekannter Fehler';
    if (error.name === 'NotAllowedError') reason = 'Zugriff verweigert. Erlaube Kamera und Mikrofon im ULTRON-Dialog.';
    if (error.name === 'NotFoundError') reason = 'Keine Kamera oder kein Mikrofon gefunden.';
    if (error.name === 'NotReadableError') reason = 'Kamera oder Mikrofon wird von einem anderen Programm verwendet. Schließe andere Apps und starte den Call erneut.';
    if (error.name === 'OverconstrainedError') reason = 'Die gewählte Kamera- oder Mikrofoneinstellung wird nicht unterstützt.';
    ultronCallSignal('callMicSignal', error.name === 'NotAllowedError' ? 'Mikrofon: Zugriff nicht erlaubt' : error.name === 'NotFoundError' ? 'Mikrofon: kein Gerät gefunden' : 'Mikrofon: Start fehlgeschlagen', 'bad');
    ultronCallSignal('callSpeechSignal', error.name === 'NotAllowedError' ? 'Stimme: Mikrofon nicht freigegeben' : 'Stimme: nicht gestartet', 'bad');
    ultronCallSignal('callAISignal', 'ULTRON: Call nicht gestartet', 'bad');
    ultronCallStatus('Call konnte nicht starten: ' + reason);
  }
}
function stopCall() {
  ultronCallRequest++;
  ultronCallStarting = false;
  calling = false;
  ultronCallCameraReady = false;
  ultronCallMicReady = false;
  ultronCallSpeaking = false;
  ultronRecognitionBlocked = false;
  ultronHandPoint = null;
  ultronHandTarget = null;
  ultronHandCursor = null;
  ultronHandRaw = null;
  ultronHandFiltered = null;
  ultronHandAnchor = null;
  ultronHandPinching = false;
  ultronLastHandSeenAt = 0;
  clearTimeout(ultronRecognitionTimer);
  clearTimeout(ultronSpeechSetupTimer);
  clearTimeout(ultronCallPartialTimer);
  clearTimeout(ultronCallTranscriptTimer);
  ultronCallPartialText = '';
  ultronCallLastCommittedTranscript = '';
  ultronCallLastCommittedAt = 0;
  ultronCallTranscriptTimer = 0;
  ultronCallTranscriptBuffer = '';
  if (recognition) {
    try { recognition.onend = null; recognition.stop(); } catch (_) {}
    recognition = null;
  }
  ultronStopOnlineRecognition(true);
  ultronStopLocalRecognition();
  ultronStopMicMonitor();
  ultronRecognitionMode = 'idle';
  ultronOnlineSpeechFailed = false;
  ultronSpeechNoiseFloor = 0.0025;
  ultronSpeechCandidateAt = 0;
  if (typeof window.ultronStopSpeaking === 'function') void window.ultronStopSpeaking();
  else if ('speechSynthesis' in window) speechSynthesis.cancel();
  if (ultronHandRaf) {
    cancelAnimationFrame(ultronHandRaf);
    ultronHandRaf = 0;
  }
  if (ultronHandLandmarker) {
    try { ultronHandLandmarker.close(); } catch (_) {}
    ultronHandLandmarker = null;
  }
  if (ultronCallStream) {
    ultronCallStream.getTracks().forEach(track => track.stop());
    ultronCallStream = null;
  }
  const video = document.getElementById('callVideo');
  if (video) video.srcObject = null;
  document.getElementById('voicePanel')?.classList.remove('call-active', 'hand-ready');
  const startButton = document.getElementById('voiceStart2');
  const stopButton = document.getElementById('voiceStop2');
  if (startButton) startButton.disabled = false;
  if (stopButton) stopButton.disabled = true;
  ultronCallSignal('callSpeechSignal', 'Stimme: aus', 'neutral');
  ultronCallSignal('callCameraSignal', 'Kamera: aus', 'neutral');
  ultronCallSignal('callMicSignal', 'Mikrofon: aus', 'neutral');
  ultronCallSignal('callHandSignal', 'Hand: aus', 'neutral');
  ultronCallSignal('callAISignal', 'ULTRON: Call beendet', 'neutral');
  ultronCallSignal('callInternetSignal', navigator.onLine ? 'Internet: bereit' : 'Internet: offline', navigator.onLine ? 'good' : 'bad');
  ultronCallStatus('Call beendet. Kamera und Mikrofon sind aus.');
}

document.getElementById('voiceStart')?.addEventListener('click', startCall);
document.getElementById('voiceStart2')?.addEventListener('click', startCall);
document.getElementById('callSpeechSetup')?.addEventListener('click', () => document.getElementById('localAIopen')?.click());
document.getElementById('voiceStop')?.addEventListener('click', stopCall);
document.getElementById('voiceStop2')?.addEventListener('click', stopCall);
document.getElementById('sayTest')?.addEventListener('click', () => speakUltron('Ich bin Ultron. System bereit. Sprachmodus aktiviert.'));
document.getElementById('voicePanel')?.querySelector('.closeTool')?.addEventListener('click', stopCall);
window.addEventListener('online', () => {
  ultronCallSignal('callInternetSignal', 'Internet: verbunden', 'good');
  if (calling) void ultronCheckCallInternet();
});
window.addEventListener('offline', () => {
  ultronCallSignal('callInternetSignal', 'Internet: offline', 'bad');
  if (calling) ultronCallStatus('Keine Internetverbindung. Die lokale Mikrofon-Erkennung bleibt aktiv; Online-Antworten sind nicht verfügbar.');
});
document.getElementById('ultronOnlineApiKey')?.addEventListener('input', () => {
  clearTimeout(ultronSpeechSetupTimer);
  if (!calling) return;
  if (window.ultronDesktop) return;
  ultronSpeechSetupTimer = setTimeout(() => {
    if (!calling || !ultronPollinationsKey() || ultronRecognitionMode === 'native' || ultronRecognitionMode === 'pollinations') return;
    ultronOnlineSpeechFailed = false;
    ultronRecognitionMode = 'blocked';
    if (ultronStartOnlineRecognition(ultronCallStream)) {
      ultronCallSignal('callSpeechSignal', 'Stimme: wartet auf Sprache', 'good');
      ultronCallStatus('Pollinations-Schlüssel erkannt. Sprich jetzt; erkannte Sprachabschnitte werden zur Transkription gesendet.');
    }
  }, 900);
});
ultronStartOrb();
